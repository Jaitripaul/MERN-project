# 🍔 Swiggy Backend Clone

<div align="center">

### 🚀 A Production-Inspired Food Delivery Backend built with Node.js, Express.js & MongoDB

Role-Based Authentication • Restaurant Management • Smart Recommendations • Fraud Detection • Real-Time Order Tracking • Dynamic Pricing

<br>

![Node.js](https://img.shields.io/badge/Node.js-339933?style=for-the-badge&logo=nodedotjs&logoColor=white)
![Express](https://img.shields.io/badge/Express.js-000000?style=for-the-badge&logo=express&logoColor=white)
![MongoDB](https://img.shields.io/badge/MongoDB-47A248?style=for-the-badge&logo=mongodb&logoColor=white)
![JWT](https://img.shields.io/badge/JWT-000000?style=for-the-badge&logo=jsonwebtokens&logoColor=white)
![Socket.IO](https://img.shields.io/badge/Socket.IO-010101?style=for-the-badge&logo=socketdotio&logoColor=white)
![Fuse.js](https://img.shields.io/badge/Fuse.js-FFCA28?style=for-the-badge)

</div>

---

## 📌 Project Overview

Swiggy Backend Clone is a production-inspired REST API developed using **Node.js**, **Express.js**, and **MongoDB** that simulates the backend architecture of a modern food delivery platform.

The project focuses on implementing real-world backend concepts such as authentication, authorization, restaurant management, menu management, shopping cart, order lifecycle, coupon management, fraud detection, dynamic pricing, intelligent delivery assignment, real-time notifications, and personalized restaurant recommendations.

Unlike a basic CRUD application, this project demonstrates enterprise backend development practices by separating business logic into controllers, services, middleware, and database models while implementing advanced features commonly found in large-scale food delivery platforms.

---

## 🌐 Live Deployment

### 🚀 Live API

**Base URL**

https://swiggy-backend-clone-usf8.onrender.com

---

### Deployment Status

- ✅ Backend Deployed on Render
- ✅ Database Hosted on MongoDB Atlas
- ✅ JWT Authentication Enabled
- ✅ REST APIs Live
- ✅ Production Ready

---

### Cloud Stack

| Service | Platform |
|----------|----------|
| Backend | Render |
| Database | MongoDB Atlas |
| Version Control | GitHub |
| API Testing | Postman |

---

## 🔗 Project Links

### 🌍 Live Backend

https://swiggy-backend-clone-usf8.onrender.com

### 💻 GitHub Repository

https://github.com/Luffy992/swiggy-backend-clone

### 📮 Postman Collection

_Coming Soon_

## 👨‍💼 Admin Access

This project implements **Role-Based Access Control (RBAC)** with three roles:

- User
- Restaurant
- Admin

By default, every registered account is assigned the **user** role.

### How to access Admin APIs

1. Register a new account using:

POST `/api/auth/register`

2. Open your MongoDB Atlas database.

3. Navigate to the **users** collection.

4. Update the user's role

## 📖 API Documentation

### Authentication

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/register` | Register a new user |
| POST | `/api/auth/login` | Login user |

### Restaurants

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/restaurants` | Create restaurant |
| GET | `/api/restaurants` | Get all restaurants |
| GET | `/api/restaurants/:id` | Get restaurant by ID |
| PUT | `/api/restaurants/:id` | Update restaurant |
| DELETE | `/api/restaurants/:id` | Delete restaurant |

### Menus

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/menus` | Add menu item |
| GET | `/api/menus/:restaurantId` | Get restaurant menu |
| PUT | `/api/menus/:id` | Update menu item |
| DELETE | `/api/menus/:id` | Delete menu item |

### Cart

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/cart` | Add item to cart |
| GET | `/api/cart` | Get user cart |
| PUT | `/api/cart/:itemId` | Update cart item |
| DELETE | `/api/cart/:itemId` | Remove cart item |
| DELETE | `/api/cart` | Clear cart |

### Orders

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/orders` | Place order |
| GET | `/api/orders/my` | My orders |
| GET | `/api/orders/:orderId` | Order details |
| PUT | `/api/orders/cancel/:orderId` | Cancel order |

### Coupons

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/coupons` | Create coupon |
| GET | `/api/coupons` | Get coupons |
| POST | `/api/coupons/apply` | Apply coupon |

### Fraud Detection

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/admin/fraud/orders` | Fraud reports |
| PUT | `/api/admin/fraud/:id/review` | Review fraud |
| PUT | `/api/admin/fraud/:id/restrict-user` | Restrict user |

### Delivery

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/delivery/create` | Create delivery partner |
| PUT | `/api/delivery/set-status` | Update delivery status |
| PUT | `/api/delivery/decline/:orderId` | Decline delivery |

## 🏗️ Project Architecture

```
                Client (Web / Mobile)
                        │
                        ▼
                 Express.js REST API
                        │
     ┌──────────┬──────────┬──────────┐
     │          │          │          │
 Authentication Restaurants Orders  Delivery
     │          │          │          │
     └──────────┴──────────┴──────────┘
                        │
                  Business Logic
                        │
                  Mongoose ODM
                        │
                MongoDB Atlas Database
```

### Request Flow

1. Client sends HTTP request.
2. Express Router receives the request.
3. Authentication middleware verifies JWT.
4. Controller processes business logic.
5. Mongoose communicates with MongoDB Atlas.
6. JSON response is returned to the client.

# ✨ Features

## Core Features

- 🔐 JWT Authentication
- 👤 Role-Based Authorization (User / Restaurant / Admin)
- 🍽 Restaurant Management
- 📋 Menu Management
- 🛒 Shopping Cart
- 📦 Order Management
- 🎟 Coupon System

---

## 🚀 Advanced Features

### ✅ Fraud Detection & Refund System

Detects suspicious user behaviour such as

- Multiple orders in a short time
- Excessive cancellations
- Coupon abuse
- Refund abuse

Automatically creates fraud reports for admin review.

---

### ✅ Advanced Restaurant Search & Filtering

Powerful search engine built using

- MongoDB Aggregation Pipeline
- Fuse.js Fuzzy Search

Supports filtering by

- Cuisine
- Rating
- Price
- Veg / Non-Veg
- Delivery Time
- Popularity

---

### ✅ Dynamic Surge Pricing

Automatically calculates delivery charges based on business rules and dynamically updates the final order amount.

---

### ✅ Smart Delivery Partner Assignment

Automatically assigns the nearest available delivery partner and supports reassignment when a delivery is declined.

---

### ✅ Real-Time Order Status & Notification System

Uses **Socket.IO** to broadcast live order status updates through every stage of the order lifecycle.

---

### ✅ Dynamic Restaurant Recommendation System

Provides personalized restaurant recommendations using

- User Order History
- Preferred Cuisines
- Frequently Ordered Items
- Restaurant Popularity
- MongoDB Aggregation Pipeline

---

# 📑 Table of Contents

- [📌 Project Overview](#-project-overview)
- [✨ Features](#-features)
- [🏗️ System Architecture](#️-system-architecture)
- [⚙️ Project Workflow](#️-project-workflow)
- [📂 Folder Structure](#-folder-structure)
- [🗄️ Database Models](#️-database-models)
- [📡 REST API Documentation](#-rest-api-documentation)
- [⭐ Advanced Features](#-advanced-features)
- [⚙️ Installation Guide](#️-installation-guide)
- [🌍 Environment Variables](#-environment-variables)
- [▶️ Running the Project](#️-running-the-project)
- [🧪 API Testing](#-api-testing)
- [🚀 Future Improvements](#-future-improvements)
- [👨‍💻 Author](#-author)

---

# 🏗️ System Architecture

```
                        Client (Frontend)
                               │
                               │
                     HTTP Requests / JWT
                               │
                               ▼
                   ┌────────────────────────┐
                   │      Express Server    │
                   └────────────────────────┘
                               │
        ┌──────────────────────┼──────────────────────┐
        │                      │                      │
        ▼                      ▼                      ▼
 Authentication          Restaurant APIs         Order APIs
        │                      │                      │
        ├──────────────┐       │       ┌──────────────┤
        ▼              ▼       ▼       ▼              ▼
 Middleware      Controllers  Services Models   Socket.IO
        │                      │                      │
        └──────────────────────┼──────────────────────┘
                               │
                               ▼
                        MongoDB Database
```

---

# ⚙️ Project Workflow

```
User
 │
 ▼
Register / Login
 │
 ▼
JWT Authentication
 │
 ▼
Browse Restaurants
 │
 ▼
Search & Filter Restaurants
 │
 ▼
View Restaurant Menu
 │
 ▼
Add Items to Cart
 │
 ▼
Apply Coupon
 │
 ▼
Place Order
 │
 ▼
Fraud Detection
 │
 ▼
Dynamic Surge Pricing
 │
 ▼
Assign Delivery Partner
 │
 ▼
Create Order
 │
 ▼
Real-Time Order Updates
 │
 ▼
Order Delivered
 │
 ▼
Recommendation Engine Learns User Preferences
```

---

# 📂 Project Structure

```text
swiggy-backend-clone/
│
├── src/
│   │
│   ├── config/
│   │
│   ├── controllers/
│   │
│   ├── middleware/
│   │
│   ├── models/
│   │
│   ├── routes/
│   │
│   ├── services/
│   │
│   ├── utils/
│   │
│   ├── app.js
│   └── server.js
│
├── package.json
├── .env
├── .gitignore
└── README.md
```

---

# 📦 Project Modules

| Module | Description |
|---------|-------------|
| Authentication | Register, Login, JWT Verification |
| Restaurant | Restaurant CRUD Operations |
| Menu | Food Item Management |
| Cart | Shopping Cart Management |
| Orders | Complete Order Lifecycle |
| Coupons | Discount & Coupon Management |
| Fraud Detection | Detect Suspicious Activities |
| Refund | Refund Processing |
| Delivery | Smart Delivery Partner Assignment |
| Recommendation | Personalized Restaurant Suggestions |
| Socket.IO | Live Order Status Notifications |

---

---

# 🗄️ Database Models

The project uses **MongoDB** as the primary database and **Mongoose ODM** for schema design and database interactions.

| Model | Purpose |
|--------|---------|
| **User** | Stores user accounts, authentication details, roles, and user preferences |
| **Restaurant** | Stores restaurant information such as name, address, cuisine, ratings, and delivery details |
| **Menu** | Stores menu items offered by restaurants |
| **Cart** | Maintains the shopping cart for each user |
| **Order** | Stores order details, payment summary, delivery status, and pricing information |
| **Coupon** | Stores coupon codes, discount rules, usage limits, and expiry dates |
| **FraudReport** | Stores suspicious activities detected by the fraud detection system |
| **Refund** | Maintains refund requests and approval status |
| **DeliveryPartner** | Stores delivery partner details, availability, and assigned orders |

---

## 👤 User Model

Responsible for authentication and personalization.

### Stores

- User Information
- Email
- Password (Encrypted using BCrypt)
- Role
- Favourite Restaurants
- Favourite Cuisines
- Favourite Food Items

---

## 🍽 Restaurant Model

Stores restaurant information including

- Restaurant Name
- Address
- Cuisine
- Rating
- Delivery Time
- Average Price
- Restaurant Status

---

## 🍕 Menu Model

Stores

- Food Name
- Category
- Price
- Description
- Veg / Non-Veg
- Availability
- Restaurant Reference

---

## 🛒 Cart Model

Stores

- User
- Selected Menu Items
- Quantity
- Total Price

---

## 📦 Order Model

Stores

- Ordered Items
- Delivery Address
- Order Status
- Delivery Fee
- Original Amount
- Discount Amount
- Final Amount
- Applied Coupon
- Assigned Delivery Partner

---

## 🎟 Coupon Model

Stores

- Coupon Code
- Discount Percentage
- Minimum Order Amount
- Maximum Discount
- Expiry Date
- Usage Limit
- Used Count
- Active Status

---

## 🚨 Fraud Report Model

Stores

- User
- Order
- Risk Score
- Fraud Reason
- Report Status
- Created Time

---

## 💸 Refund Model

Stores

- Order
- Refund Amount
- Refund Reason
- Refund Status
- Processed Date

---

## 🛵 Delivery Partner Model

Stores

- Name
- Phone Number
- Vehicle Details
- Current Location
- Availability Status
- Assigned Orders

---

# 📡 REST API Documentation

## 🔐 Authentication APIs

| Method | Endpoint | Description |
|----------|----------|-------------|
| POST | `/api/auth/register` | Register a new user |
| POST | `/api/auth/login` | Login and receive JWT token |
| GET | `/api/auth/profile` | Get logged-in user profile |

---

## 🍽 Restaurant APIs

| Method | Endpoint | Description |
|----------|----------|-------------|
| POST | `/api/restaurants` | Create Restaurant |
| GET | `/api/restaurants` | Get All Restaurants |
| GET | `/api/restaurants/:id` | Get Restaurant Details |
| PUT | `/api/restaurants/:id` | Update Restaurant |
| DELETE | `/api/restaurants/:id` | Delete Restaurant |

---

## 🍕 Menu APIs

| Method | Endpoint | Description |
|----------|----------|-------------|
| POST | `/api/menu` | Add Menu Item |
| GET | `/api/menu/:restaurantId` | Get Restaurant Menu |
| PUT | `/api/menu/:id` | Update Menu Item |
| DELETE | `/api/menu/:id` | Delete Menu Item |

---

## 🛒 Cart APIs

| Method | Endpoint | Description |
|----------|----------|-------------|
| POST | `/api/cart/add` | Add Item to Cart |
| GET | `/api/cart` | View Cart |
| PUT | `/api/cart/update` | Update Cart Item |
| DELETE | `/api/cart/remove/:id` | Remove Item from Cart |

---

## 📦 Order APIs

| Method | Endpoint | Description |
|----------|----------|-------------|
| POST | `/api/orders/create` | Place Order |
| GET | `/api/orders` | Get User Orders |
| GET | `/api/orders/:id` | Get Order Details |
| PUT | `/api/orders/status/:id` | Update Order Status |
| DELETE | `/api/orders/cancel/:id` | Cancel Order |

---

## 🎟 Coupon APIs

| Method | Endpoint | Description |
|----------|----------|-------------|
| POST | `/api/coupons` | Create Coupon |
| GET | `/api/coupons` | Get All Coupons |
| POST | `/api/coupons/apply` | Apply Coupon |

---

## 🛵 Delivery APIs

| Method | Endpoint | Description |
|----------|----------|-------------|
| POST | `/api/delivery/assign/:orderId` | Assign Delivery Partner |
| GET | `/api/delivery/orders` | View Assigned Orders |
| PUT | `/api/delivery/status/:orderId` | Update Delivery Status |

---

## ⭐ Recommendation APIs

| Method | Endpoint | Description |
|----------|----------|-------------|
| GET | `/api/restaurants/recommendations/:userId` | Personalized Restaurant Recommendations |

---

## 🚨 Fraud Detection APIs

| Method | Endpoint | Description |
|----------|----------|-------------|
| GET | `/api/admin/fraud/orders` | View Suspicious Orders |
| GET | `/api/admin/fraud/reports` | View Fraud Reports |

---

---

# ⭐ Advanced Features

Unlike a basic food delivery backend, this project implements multiple production-inspired features that improve security, scalability, user experience, and system intelligence.

---

# 1️⃣ Fraud Detection & Refund System

## 📌 Overview

The Fraud Detection & Refund System helps identify suspicious user activities before they impact the platform. Every order is analyzed using predefined business rules, and risky transactions are automatically flagged for administrative review.

---

## 🎯 Objectives

- Prevent fraudulent orders
- Reduce refund abuse
- Detect coupon misuse
- Improve platform security
- Assist administrators in reviewing suspicious transactions

---

## ⚙️ Detection Rules

The system monitors activities such as:

- Multiple orders placed within a short time
- Frequent order cancellations
- Excessive refund requests
- Abnormal coupon usage
- High-risk user behavior

Each suspicious activity contributes to a **Risk Score**.

---

## 🔄 Workflow

```
User Places Order
        │
        ▼
Fraud Detection Service
        │
        ▼
Calculate Risk Score
        │
        ├────────── Safe
        │
        ▼
 Continue Order

        │

        └────────── Suspicious
                    │
                    ▼
          Generate Fraud Report
                    │
                    ▼
          Admin Review Required
```

---

## ✅ Benefits

- Protects business revenue
- Reduces fake orders
- Detects suspicious behavior automatically
- Improves platform trust

---

# 2️⃣ Advanced Restaurant Search & Filtering

## 📌 Overview

The search module allows users to quickly discover restaurants using both exact matching and fuzzy searching powered by **Fuse.js**.

---

## Features

- Search by restaurant name
- Search by cuisine
- Fuzzy search for spelling mistakes
- Rating filter
- Price filter
- Delivery time filter
- Veg / Non-Veg filter
- Popularity filter

---

## Technologies Used

- MongoDB Aggregation Pipeline
- Fuse.js
- MongoDB Indexing

---

## Search Workflow

```
Search Request
      │
      ▼
Aggregation Pipeline
      │
      ▼
Apply Filters
      │
      ▼
Fuse.js Fuzzy Search
      │
      ▼
Sorted Restaurant Results
```

---

## Benefits

- Faster search
- Better user experience
- Handles spelling mistakes
- Efficient filtering

---

# 3️⃣ Dynamic Surge Pricing

## 📌 Overview

The delivery pricing system dynamically calculates delivery fees based on configurable business rules instead of using a fixed delivery charge.

---

## Features

- Dynamic delivery fee calculation
- Automatic total amount calculation
- Original amount tracking
- Discount calculation
- Final payable amount generation

---

## Pricing Flow

```
Cart Total
      │
      ▼
Apply Coupon
      │
      ▼
Calculate Discount
      │
      ▼
Calculate Delivery Fee
      │
      ▼
Generate Final Amount
```

---

## Benefits

- Flexible pricing strategy
- Easy to extend with peak-hour logic
- Transparent billing

---

# 4️⃣ Smart Delivery Partner Assignment

## 📌 Overview

Instead of manually assigning deliveries, the backend automatically assigns an available delivery partner to newly created orders.

---

## Features

- Delivery partner management
- Availability tracking
- Automatic assignment
- Reassignment support
- Order ownership tracking

---

## Assignment Workflow

```
Order Created
      │
      ▼
Find Available Partner
      │
      ▼
Assign Delivery Partner
      │
      ▼
Update Order
      │
      ▼
Partner Starts Delivery
```

---

## Benefits

- Reduces manual work
- Faster order processing
- Better delivery management

---

# 5️⃣ Real-Time Order Status & Notification System

## 📌 Overview

The backend uses **Socket.IO** to broadcast order status updates instantly, allowing connected clients to receive live notifications.

---

## Features

- Live order status updates
- Instant notifications
- Event broadcasting
- Order lifecycle tracking

---

## Order Lifecycle

```
Order Placed
      │
      ▼
Preparing
      │
      ▼
Picked Up
      │
      ▼
Out For Delivery
      │
      ▼
Delivered
```

Every status change is emitted using Socket.IO.

---

## Benefits

- Better customer experience
- Instant communication
- Real-time synchronization

---

# 6️⃣ Dynamic Restaurant Recommendation System

## 📌 Overview

The recommendation engine provides personalized restaurant suggestions based on each user's ordering behavior.

---

## Recommendation Factors

- Favourite cuisines
- Favourite restaurants
- Frequently ordered menu items
- Restaurant popularity
- Restaurant ratings

---

## Recommendation Workflow

```
User Order History
        │
        ▼
Update User Preferences
        │
        ▼
Aggregation Pipeline
        │
        ▼
Calculate Recommendation Score
        │
        ▼
Return Personalized Restaurants
```

---

## Technologies Used

- MongoDB Aggregation Pipeline
- User Preference Analysis
- Recommendation Service

---

## Benefits

- Personalized experience
- Better restaurant discovery
- Increased customer engagement

---

# 📊 Project Highlights

| Category | Status |
|----------|--------|
| JWT Authentication | ✅ |
| Role-Based Authorization | ✅ |
| Restaurant Management | ✅ |
| Menu Management | ✅ |
| Cart System | ✅ |
| Order Management | ✅ |
| Coupon System | ✅ |
| Fraud Detection | ✅ |
| Refund System | ✅ |
| Smart Search | ✅ |
| Dynamic Pricing | ✅ |
| Delivery Assignment | ✅ |
| Real-Time Notifications | ✅ |
| Recommendation Engine | ✅ |

---

---

# ⚙️ Installation Guide

Follow these steps to set up the project locally.

## 1️⃣ Clone the Repository

```bash
git clone https://github.com/Luffy992/swiggy-backend-clone.git
```

---

## 2️⃣ Navigate to the Project

```bash
cd swiggy-backend-clone
```

---

## 3️⃣ Install Dependencies

```bash
npm install
```

---

## 4️⃣ Configure Environment Variables

Create a `.env` file in the project root.

Example:

```env
PORT=5000

MONGO_URI=your_mongodb_connection_string

JWT_SECRET=your_secret_key
```

---

## 5️⃣ Start the Development Server

```bash
npm run dev
```

The server will start on:

```
http://localhost:5000
```

---

# 🌍 Environment Variables

| Variable | Description |
|-----------|-------------|
| PORT | Server Port |
| MONGO_URI | MongoDB Connection String |
| JWT_SECRET | Secret key used to generate JWT Tokens |

---

# ▶️ Running the Project

Development Mode

```bash
npm run dev
```

Production Mode

```bash
npm start
```

---

# 🧪 API Testing

All APIs can be tested using **Postman**.

The collection includes modules for:

- Authentication
- Restaurants
- Menu
- Cart
- Orders
- Coupons
- Fraud Detection
- Refund
- Delivery
- Recommendations

### Typical API Flow

```
Register User
      │
      ▼
Login
      │
      ▼
Copy JWT Token
      │
      ▼
Authorize Requests
      │
      ▼
Create Restaurant
      │
      ▼
Add Menu
      │
      ▼
Add Items to Cart
      │
      ▼
Apply Coupon
      │
      ▼
Place Order
      │
      ▼
Receive Real-Time Updates
```

---

# 🔒 Security Features

This project follows several backend security best practices.

- Password hashing using BCrypt
- JWT-based authentication
- Role-Based Authorization
- Protected Routes
- Environment Variables
- Fraud Detection
- Coupon Validation
- Request Validation

---

# 🚀 Future Improvements

Potential enhancements include:

- 💳 Payment Gateway Integration (Stripe/Razorpay)
- 🐳 Docker Support
- ☸️ Kubernetes Deployment
- ⚡ Redis Caching
- 📩 Email Notifications
- 📱 SMS Notifications
- 🔔 Push Notifications
- 📊 Admin Dashboard
- 📍 Live GPS Tracking
- 🌐 Microservices Architecture
- ☁️ AWS Deployment
- 📈 Monitoring with Prometheus & Grafana
- 🔄 CI/CD Pipeline using GitHub Actions

---

# 🤝 Contributing

Contributions are welcome!

If you'd like to improve this project:

1. Fork the repository
2. Create a new feature branch

```bash
git checkout -b feature/new-feature
```

3. Commit your changes

```bash
git commit -m "Add new feature"
```

4. Push to your branch

```bash
git push origin feature/new-feature
```

5. Open a Pull Request

---

# 📄 License

This project is licensed under the **MIT License**.

You are free to use, modify, and distribute this project for learning and educational purposes.

---

# 👨‍💻 Author

### M Luffy

Backend Developer | Java | Spring Boot | Node.js | Express.js | MongoDB

📧 Email: someshramola03@gmail.com

🔗 GitHub: https://github.com/Luffy992

🔗 LinkedIn: https://www.linkedin.com/in/somesh-ramola-293b3741b

---

# ⭐ Support

If you found this project useful, consider giving it a ⭐ on GitHub.

It helps others discover the project and motivates future improvements.

---

<div align="center">

## 🍔 Thank You for Visiting!

If you have any feedback, suggestions, or ideas, feel free to open an issue or connect with me.

⭐ Happy Coding! ⭐

</div>
