const mongoose = require("mongoose");

const surgeSettingSchema = new mongoose.Schema(
  {
    baseDeliveryFee: {
      type: Number,
      default: 40,
    },

    surgeMultiplier: {
      type: Number,
      default: 1.5,
    },

    peakStartHour: {
      type: Number,
      default: 12,
    },

    peakEndHour: {
      type: Number,
      default: 14,
    },

    eveningPeakStart: {
      type: Number,
      default: 19,
    },

    eveningPeakEnd: {
      type: Number,
      default: 22,
    },

    highDemandThreshold: {
      type: Number,
      default: 20,
    },
  },
  {
    timestamps: true,
  }
);

module.exports = mongoose.model("SurgeSetting", surgeSettingSchema);