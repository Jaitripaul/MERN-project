const mongoose = require("mongoose");

const userSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    email: {
      type: String,
      required: true,
    },
    password: {
      type: String,
      required: true,
      select: false,
    },
    role: {
      type: String,
      enum: ["user", "admin", "restaurant"],
      default: "user",
    },

    preferences: {
      favoriteCuisines: [
        {
          type: String
        }
      ],
      favoriteRestaurants: [
        {
          type: mongoose.Schema.Types.ObjectId,
          ref: "Restaurant"
        }
      ],
      favoriteItems: [
        {
          type: String
        }
      ]
    },
    isblocked: {
      type: Boolean,
      default: false,
    },
    blockedUntil: {
      type: Date,
      default: null,
    },
  },
  { timestamps: true },
);

module.exports = mongoose.model("User", userSchema);
