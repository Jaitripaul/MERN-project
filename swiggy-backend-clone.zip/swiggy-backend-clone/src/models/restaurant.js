const mongoose = require("mongoose");

const restaurantSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
    },
    owner: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: true,
    },
    city: {
      type: String,
      required: true,
    },
    location: {
      latitude: {
        type: Number,
        required: true,
      },
      longitude: {
        type: Number,
        required: true,
      },
    },
    address: {
      type: String,
      required: true,
    },
    cuisine: {
      type: [String],
      default: [],
    },

    priceRange: {
      type: Number,
      min: 1,
      max: 5,
      default: 2,
    },

    estimatedDeliveryTime: {
      type: Number,
      default: 30,
    },

    isPureVeg: {
      type: Boolean,
      default: false,
    },

    popularity: {
      type: Number,
      default: 0,
    },
    rating: {
      type: Number,
      default: 0,
    },
    image: {
      type: String,
    },
    isApproved: {
      type: Boolean,
      default: false,
    },
  },
  { timestamps: true },
);

// Text search index
restaurantSchema.index({
  name: "text",
  city: "text",
  cuisine: "text",
});

// Sorting indexes
restaurantSchema.index({ rating: -1 });
restaurantSchema.index({ popularity: -1 });
restaurantSchema.index({ estimatedDeliveryTime: 1 });
restaurantSchema.index({ priceRange: 1 });

module.exports = mongoose.model("Restaurant", restaurantSchema);
