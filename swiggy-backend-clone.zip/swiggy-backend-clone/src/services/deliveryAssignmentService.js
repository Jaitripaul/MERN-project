const DeliveryPartner = require("../models/DeliveryPartner");

function calculateDistance(lat1, lon1, lat2, lon2) {
  return Math.sqrt(
    Math.pow(lat1 - lat2, 2) +
    Math.pow(lon1 - lon2, 2)
  );
}

async function assignDeliveryPartner(restaurantLocation) {

  const partners = await DeliveryPartner.find({
    isAvailable: true,
    isActive: true,
  });

  if (!partners.length) {
    return null;
  }

  let bestPartner = null;
  let shortestDistance = Number.MAX_VALUE;

  for (const partner of partners) {

    const distance = calculateDistance(
      restaurantLocation.latitude,
      restaurantLocation.longitude,
      partner.location.latitude,
      partner.location.longitude
    );

    if (
      distance < shortestDistance &&
      partner.currentOrders < 5
    ) {
      shortestDistance = distance;
      bestPartner = partner;
    }
  }

  if (!bestPartner) {
    return null;
  }

  bestPartner.currentOrders += 1;
  await bestPartner.save();

  return bestPartner;
}

module.exports = {
  assignDeliveryPartner,
};