const Order = require("../models/order");
const Coupon = require("../models/Coupon");
const Refund = require("../models/Refund");

/**
 * Analyze user behavior and calculate fraud risk.
 * Returns:
 * {
 *   riskScore: Number,
 *   reasons: []
 * }
 */
exports.calculateRisk = async (userId) => {
  let riskScore = 0;
  const reasons = [];

  const now = new Date();

  // ===============================
  // 1. Multiple Orders (Last 5 Minutes)
  // ===============================
  const fiveMinutesAgo = new Date(now.getTime() - 5 * 60 * 1000);

  const recentOrders = await Order.find({
    user: userId,
    createdAt: { $gte: fiveMinutesAgo },
  });

  if (recentOrders.length >= 3) {
    riskScore += 40;
    reasons.push("Multiple orders placed within 5 minutes");
  }

  // ==================================
  // 2. Repeated Order Cancellations (7 Days)
  // ==================================
  const sevenDaysAgo = new Date(
    now.getTime() - 7 * 24 * 60 * 60 * 1000
  );

  const cancelledOrders = await Order.find({
    user: userId,
    orderStatus: "Cancelled",
    updatedAt: { $gte: sevenDaysAgo },
  });

  if (cancelledOrders.length >= 3) {
    riskScore += 30;
    reasons.push("Repeated order cancellations");
  }

  // ==========================
  // 3. Coupon Abuse Detection
  // ==========================
  const couponUsage = await Coupon.aggregate([
    {
      $unwind: "$usedBy",
    },
    {
      $match: {
        "usedBy.user": userId,
        "usedBy.usedAt": {
          $gte: sevenDaysAgo,
        },
      },
    },
    {
      $count: "totalUses",
    },
  ]);

  if (couponUsage.length > 0 && couponUsage[0].totalUses >= 5) {
    riskScore += 30;
    reasons.push("Abnormal coupon usage detected");
  }

  // ==========================
  // Refund Abuse Detection
  // ==========================

  const refundRequests = await Refund.find({
    user: userId,
    createdAt: {
      $gte: sevenDaysAgo,
    },
  });

  if (refundRequests.length >= 3) {
    riskScore += 30;
    reasons.push("Excessive refund requests");
  }

  return {
    riskScore,
    reasons,
  };
};