const Order = require("../models/order");
const Restaurant = require("../models/restaurant");
const User = require("../models/User");

const getRecommendedRestaurants = async (userId) => {
  try {
    const user = await User.findById(userId);

    if (!user) {
      throw new Error("User not found");
    }

    const favoriteCuisines = user.preferences?.favoriteCuisines || [];

    const recommendations = await Restaurant.aggregate([
      {
        $match: {
          isApproved: true
        }
      },
      {
        $lookup: {
          from: "orders",
          localField: "_id",
          foreignField: "restaurant",
          as: "orders"
        }
      },
      {
        $addFields: {
          totalOrders: {
            $size: "$orders"
          }
        }
      },
      {
        $addFields: {
          recommendationScore: {
            $add: [
              {
                $cond: [
                  {
                    $in: ["$cuisine", favoriteCuisines]
                  },
                  40,
                  0
                ]
              },
              {
                $multiply: [
                  {
                    $ifNull: ["$rating", 0]
                  },
                  5
                ]
              },
              {
                $min: [
                  "$totalOrders",
                  20
                ]
              }
            ]
          }
        }
      },
      {
        $sort: {
          recommendationScore: -1
        }
      },
      {
        $project: {
          orders: 0
        }
      }
    ]);

    return recommendations;

  } catch (error) {
    throw error;
  }
};

module.exports = {
  getRecommendedRestaurants
};