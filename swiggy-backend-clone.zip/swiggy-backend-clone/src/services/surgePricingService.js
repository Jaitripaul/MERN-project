const Order = require("../models/order");
const SurgeSetting = require("../models/SurgeSetting");

exports.calculateDeliveryFee = async () => {
  // Get admin settings
  let settings = await SurgeSetting.findOne();

  // If no settings exist, create default settings
  if (!settings) {
    settings = await SurgeSetting.create({});
  }

  const now = new Date();
  const currentHour = now.getHours();

  let deliveryFee = settings.baseDeliveryFee;
  let surgeApplied = false;
  let reason = "Normal Delivery";

  // ==========================
  // Peak Hour Check
  // ==========================
  const isLunchPeak =
    currentHour >= settings.peakStartHour &&
    currentHour < settings.peakEndHour;

  const isDinnerPeak =
    currentHour >= settings.eveningPeakStart &&
    currentHour < settings.eveningPeakEnd;

  if (isLunchPeak || isDinnerPeak) {
    deliveryFee *= settings.surgeMultiplier;
    surgeApplied = true;
    reason = "Peak Hour Surge";
  }

  // ==========================
  // High Demand Check
  // Orders placed in last hour
  // ==========================
  const oneHourAgo = new Date(
    now.getTime() - 60 * 60 * 1000
  );

  const recentOrders = await Order.countDocuments({
    createdAt: {
      $gte: oneHourAgo,
    },
  });

  if (recentOrders >= settings.highDemandThreshold) {
    deliveryFee *= settings.surgeMultiplier;
    surgeApplied = true;
    reason = "High Demand Surge";
  }

  return {
    baseFee: settings.baseDeliveryFee,
    deliveryFee: Math.round(deliveryFee),
    surgeApplied,
    reason,
    recentOrders,
  };
};