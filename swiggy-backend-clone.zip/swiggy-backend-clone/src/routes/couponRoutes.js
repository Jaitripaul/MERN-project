const express = require("express");
const router = express.Router();

const { protect, authorize } = require("../middleware/authMiddleware");

const {
  createCoupon,
  getCoupons,
  updateCoupon,
  deleteCoupon,
  applyCoupon,
} = require("../controllers/couponController");

// Public
router.get("/", getCoupons);

// Admin Only
router.post("/", protect, authorize("admin"), createCoupon);

router.put("/:id", protect, authorize("admin"), updateCoupon);

router.delete("/:id", protect, authorize("admin"), deleteCoupon);

router.post(
  "/apply",
  protect,
  authorize("user"),
  applyCoupon
);

module.exports = router;