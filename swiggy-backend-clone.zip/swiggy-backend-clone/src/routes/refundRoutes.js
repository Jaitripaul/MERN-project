const express = require("express");

const router = express.Router();

const {
  requestRefund,
  getMyRefunds,
} = require("../controllers/refundController");

const { protect, authorize } = require("../middleware/authMiddleware");

router.use(protect);
router.use(authorize("user"));

// User requests refund
router.post("/request", requestRefund);

// User refund history
router.get("/my", getMyRefunds);

module.exports = router;