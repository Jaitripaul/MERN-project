const express = require("express");
const router = express.Router();

const { protect, authorize } = require("../middleware/authMiddleware");
const {
  getallUsers,
  toggleBlockUser,
  approveRestaurant,
  getAllOrders,
  getPlatformStatistics,
  getFraudOrders,
  reviewFraudOrder,
  restrictUser,
  createRestaurantByAdmin,
  updateRestaurantByAdmin,
  getSurgeSettings,
  updateSurgeSettings,
  getAllRefundRequests,
  reviewRefundRequest,
} = require("../controllers/AdminController");

router.use(protect);
router.use(authorize("admin"));

router.get("/", getallUsers);
router.put("/users/:id/block", toggleBlockUser);
router.put("/restaurant/:id/approve", approveRestaurant);
router.get("/statistics", getPlatformStatistics);
router.get("/orders", getAllOrders);

router.get(
  "/surge-settings",
  getSurgeSettings
);

router.put(
  "/surge-settings",
  updateSurgeSettings
);

router.get(
  "/refunds",
  getAllRefundRequests
);

router.put(
  "/refunds/:id",
  reviewRefundRequest
);

router.post(
  "/restaurants/create",
  createRestaurantByAdmin
);

router.put(
  "/restaurants/update/:restaurantId",
  updateRestaurantByAdmin
);

// Fraud Management
router.get("/fraud/orders", getFraudOrders);

router.put("/fraud/:id/review", reviewFraudOrder);

router.put("/fraud/:id/restrict-user", restrictUser);

module.exports = router;
