const express = require("express");
const router = express.Router();

const { protect, authorize } = require("../middleware/authMiddleware");

const {
  placeOrder,
  getMyOrders,
  getRestaurantOrders,
  updateOrderStatus,
  mockPayment,
  cancelOrder,
  calculateDeliveryFee,
  getOrderDetails,
} = require("../controllers/orderController");

// User Routes
router.post("/", protect, authorize("user"), placeOrder);
router.get("/my", protect, authorize("user"), getMyOrders);
router.put("/cancel/:orderId", protect, authorize("user"), cancelOrder);
router.post("/verify", protect, authorize("user"), mockPayment);

// Shared Route
router.get("/calculate-delivery-fee", protect, calculateDeliveryFee);

// Restaurant Routes
router.get("/restaurant", protect, authorize("restaurant"), getRestaurantOrders);
router.put("/:id/status", protect, authorize("restaurant"), updateOrderStatus);

// Shared Route
router.get("/:orderId", protect, getOrderDetails);

module.exports = router;