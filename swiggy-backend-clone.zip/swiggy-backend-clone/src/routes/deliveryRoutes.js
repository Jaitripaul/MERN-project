const express = require("express");

const router = express.Router();

const {
  createDeliveryPartner,
  setAvailabilityStatus,
  declineDelivery,
} = require("../controllers/deliveryController");

router.post("/create", createDeliveryPartner);

router.put("/set-status", setAvailabilityStatus);

router.put("/decline/:orderId", declineDelivery);

module.exports = router;