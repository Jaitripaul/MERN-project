const express = require("express");
const router = express.Router();
const {
  createRestaurant,
  getMyRestaurant,
  updateRestaurant,
  getAllRestaurants,
  searchRestaurants,
  getRecommendations,
} = require("../controllers/restaurantController");
const { protect, authorize } = require("../middleware/authMiddleware");

router.post("/", protect, createRestaurant);

router.put("/:id", protect, updateRestaurant);

router.get("/my", protect, getMyRestaurant);
router.get("/search", searchRestaurants);
router.get("/", getAllRestaurants);
router.get(
  "/recommendations/:userId",
  protect,
  authorize("user"),
  getRecommendations
);

module.exports = router;
