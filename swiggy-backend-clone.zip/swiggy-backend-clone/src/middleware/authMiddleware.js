const jwt = require("jsonwebtoken");
const User = require("../models/User");

exports.protect = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(" ")[1];
    if (!token) {
      return res
        .status(401)
        .json({ success: false, message: "Not authorized" });
    }
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);
    if (!user) {
      return res.status(401).json({
        success: false,
        message: "Access denied",
      });
    }

    if (user.isblocked) {

      if (user.blockedUntil && user.blockedUntil > new Date()) {

        return res.status(403).json({
          success: false,
          message: `Account temporarily restricted until ${user.blockedUntil}`,
        });

      }

      // Restriction expired
      user.isblocked = false;
      user.blockedUntil = null;

      await user.save();
    }
    console.log("Logged in user:", user.email, user.role);
    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({ success: false, message: "Invalid token" });
  }
};

exports.authorize = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ success: false, message: "Forbidden" });
    }
    next();
  };
};
