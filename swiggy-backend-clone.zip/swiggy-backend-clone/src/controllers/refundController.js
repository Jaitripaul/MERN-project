const Refund = require("../models/Refund");
const Order = require("../models/order");
const FraudReport = require("../models/FraudReport");
const { calculateRisk } = require("../services/fraudDetectionService");

// ==============================
// User Request Refund
// ==============================
exports.requestRefund = async (req, res) => {
  try {
    const { orderId, reason } = req.body;

    const order = await Order.findById(orderId);

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    // Check ownership
    if (order.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: "You are not allowed to request a refund for this order",
      });
    }

    // Prevent duplicate requests
    const existingRefund = await Refund.findOne({
      order: orderId,
    });

    if (existingRefund) {
      return res.status(400).json({
        success: false,
        message: "Refund request already exists",
      });
    }

    const refund = await Refund.create({
      order: orderId,
      user: req.user._id,
      reason,
    });

    const fraudResult = await calculateRisk(req.user._id);

if (fraudResult.riskScore >= 40) {

  const existingReport = await FraudReport.findOne({
    user: req.user._id,
    status: "Pending",
  });

  if (!existingReport) {

    await FraudReport.create({
      order: orderId,
      user: req.user._id,
      riskScore: fraudResult.riskScore,
      reasons: fraudResult.reasons,
    });

  }

}

    res.status(201).json({
      success: true,
      message: "Refund request submitted successfully",
      data: refund,
    });

  } catch (error) {

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }
};

// ==============================
// User Refund History
// ==============================
exports.getMyRefunds = async (req, res) => {
  try {

    const refunds = await Refund.find({
      user: req.user._id,
    })
      .populate("order")
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: refunds.length,
      data: refunds,
    });

  } catch (error) {

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }
};