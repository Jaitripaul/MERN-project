const Order = require("../models/order");
const Cart = require("../models/Cart");
const Restaurant = require("../models/restaurant");
const User = require("../models/User");

const FraudReport = require("../models/FraudReport");
const { calculateRisk } = require("../services/fraudDetectionService");

const Coupon = require("../models/Coupon");
const { calculateDeliveryFee } = require("../services/surgePricingService");
const { assignDeliveryPartner } = require("../services/deliveryAssignmentService");


// ✅ Place Order
exports.placeOrder = async (req, res) => {
  try {
    const { deliveryAddress } = req.body;

    const cart = await Cart.findOne({ user: req.user._id })
      .populate("items.menuItem")
      .populate("restaurant");

    if (!cart || cart.items.length === 0) {
      return res.status(400).json({
        success: false,
        message: "Cart is empty"
      });
    }

    // Validate restaurant approved
    if (!cart.restaurant.isApproved) {
      return res.status(400).json({
        success: false,
        message: "Restaurant not approved"
      });
    }

    // Recalculate total securely
    const items = cart.items.map(item => ({
      menuItem: item.menuItem._id,
      name: item.menuItem.name,
      price: item.menuItem.price,
      quantity: item.quantity
    }));

    const totalAmount = items.reduce((total, item) => {
      return total + item.price * item.quantity;
    }, 0);

    const discountAmount = cart.discountAmount || 0;
    const finalAmount = totalAmount - discountAmount;
    const deliveryCharge = await calculateDeliveryFee();

    const deliveryPartner = await assignDeliveryPartner(
      cart.restaurant.location
    );
    const order = await Order.create({
      user: req.user._id,
      restaurant: cart.restaurant._id,
      deliveryPartner: deliveryPartner ? deliveryPartner._id : null,
      items,
      originalAmount: totalAmount,
      discountAmount,
      coupon: cart.coupon,
      totalAmount: finalAmount,
      deliveryFee: deliveryCharge.deliveryFee,

      finalAmount:
        finalAmount + deliveryCharge.deliveryFee,
      deliveryAddress,
    });

    // Update user preferences for recommendations
    const user = await User.findById(req.user._id);

    if (user) {
      // Add cuisine if not already present
      if (
        cart.restaurant.cuisine &&
        !user.preferences.favoriteCuisines.includes(cart.restaurant.cuisine)
      ) {
        user.preferences.favoriteCuisines.push(cart.restaurant.cuisine);
      }

      // Add restaurant if not already present
      const alreadyVisited = user.preferences.favoriteRestaurants.some(
        (restaurantId) =>
          restaurantId.toString() === cart.restaurant._id.toString()
      );

      if (!alreadyVisited) {
        user.preferences.favoriteRestaurants.push(cart.restaurant._id);
      }

      // Add ordered menu item names
      items.forEach((item) => {
        if (!user.preferences.favoriteItems.includes(item.name)) {
          user.preferences.favoriteItems.push(item.name);
        }
      });

      await user.save();
    }

    // Consume coupon only after successful order
    if (cart.coupon) {
      const coupon = await Coupon.findById(cart.coupon);

      if (coupon) {
        coupon.usedCount += 1;

        coupon.usedBy.push({
          user: req.user._id,
          usedAt: new Date(),
        });

        await coupon.save();
      }
    }


    // Check fraud risk
    const fraudResult = await calculateRisk(req.user._id);

    if (fraudResult.riskScore >= 40) {

      const existingReport = await FraudReport.findOne({
        user: req.user._id,
        status: "Pending",
      });

      if (!existingReport) {
        await FraudReport.create({
          order: order._id,
          user: req.user._id,
          riskScore: fraudResult.riskScore,
          reasons: fraudResult.reasons,
        });
      }

    }

    // Clear cart after order
    await Cart.findOneAndDelete({ user: req.user._id });

    res.status(201).json({
      success: true,
      message: "Order placed successfully",
      data: order
    });

  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};



// ✅ Get My Orders
exports.getMyOrders = async (req, res) => {
  try {
    const orders = await Order.find({ user: req.user._id })
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: orders
    });

  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};



// ✅ Get Restaurant Orders
exports.getRestaurantOrders = async (req, res) => {
  try {
    const myRestaurant = await Restaurant.findOne({ owner: req.user._id });

    if (!myRestaurant) {
      return res.status(404).json({
        success: false,
        message: "Restaurant not found"
      });
    }

    const orders = await Order.find({ restaurant: myRestaurant._id })
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      data: orders
    });

  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

exports.mockPayment = async (req, res) => {
  const { orderId } = req.body;

  const order = await Order.findById(orderId);

  order.paymentStatus = "Paid";
  order.orderStatus = "Confirmed";

  await order.save();

  res.status(200).json({
    success: true,
    message: "Mock payment successful"
  });
};

// ✅ Update Order Status (Restaurant Only)
exports.updateOrderStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const order = await Order.findById(req.params.id).populate("restaurant");
    console.log("Logged in user:", req.user._id.toString());
    console.log("Order restaurant:", order.restaurant.owner.toString());

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    // Verify restaurant ownership
    const myRestaurant = await Restaurant.findOne({
      owner: req.user._id,
    });

    console.log("Restaurant found:", Restaurant?._id.toString());
    console.log("Order restaurant id:", order.restaurant._id.toString());

    if (
      !myRestaurant ||
      myRestaurant._id.toString() !== order.restaurant._id.toString()
    ) {
      return res.status(403).json({
        success: false,
        message: "Not authorized",
      });
    }

    order.orderStatus = status;
    await order.save();

    // Send real-time notification
    const io = req.app.get("io");

    io.emit("orderStatusUpdated", {
      orderId: order._id,
      status: order.orderStatus,
      message: `Order status changed to ${order.orderStatus}`,
    });

    res.status(200).json({
      success: true,
      message: "Order status updated",
      data: order,
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// ✅ Cancel Order (User Only)
exports.cancelOrder = async (req, res) => {
  try {
    const { orderId } = req.params;

    // Find the order
    const order = await Order.findById(orderId);

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    // Check ownership
    if (order.user.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: "You are not authorized to cancel this order",
      });
    }

    // Already cancelled
    if (order.orderStatus === "Cancelled") {
      return res.status(400).json({
        success: false,
        message: "Order is already cancelled",
      });
    }

    // Delivered orders cannot be cancelled
    if (order.orderStatus === "Delivered") {
      return res.status(400).json({
        success: false,
        message: "Delivered orders cannot be cancelled",
      });
    }

    // Cancel order
    order.orderStatus = "Cancelled";
    await order.save();

    // Recalculate fraud risk
    const fraudResult = await calculateRisk(req.user._id);

    if (fraudResult.riskScore >= 50) {

      const existingReport = await FraudReport.findOne({
        user: req.user._id,
        status: "Pending",
      });

      if (!existingReport) {
        await FraudReport.create({
          order: order._id,
          user: req.user._id,
          riskScore: fraudResult.riskScore,
          reasons: fraudResult.reasons,
        });
      }

    }

    res.status(200).json({
      success: true,
      message: "Order cancelled successfully",
      data: order,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Calculate Delivery Fee
exports.calculateDeliveryFee = async (req, res) => {
  try {
    const result = await calculateDeliveryFee();

    res.status(200).json({
      success: true,
      data: result,
    });

  } catch (error) {

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }
};

// ✅ Get Single Order Details
exports.getOrderDetails = async (req, res) => {
  try {
    const order = await Order.findById(req.params.orderId)
      .populate("user", "name email")
      .populate("restaurant", "name")
      .populate("deliveryPartner", "name phone email");

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    res.status(200).json({
      success: true,
      data: order,
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};