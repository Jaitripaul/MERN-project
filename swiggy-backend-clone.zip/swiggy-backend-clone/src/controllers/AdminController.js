const Order = require("../models/order");
const User = require("../models/User");
const Restaurant = require("../models/restaurant");
const FraudReport = require("../models/FraudReport");
const SurgeSetting = require("../models/SurgeSetting");
const Refund = require("../models/Refund");

exports.getallUsers = async (req, res) => {
  try {
    const users = await User.find().select("-password");
    res.status(200).json({
      success: true,
      data: users,
      count: users.length,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

exports.toggleBlockUser = async (req, res) => {
  try {
    const user = await User.findById(req.params.id);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    user.isblocked = !user.isblocked;
    await user.save();

    res.status(200).json({
      success: true,
      message: `User ${user.isBlocked ? "blocked" : "unblocked"} successfully`,
      data: user,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

exports.approveRestaurant = async (req, res) => {
  try {
    const Restaurant = await restaurant.findById(req.params.id);

    if (!Restaurant) {
      return res.status(404).json({
        success: false,
        message: "Restaurant not found",
      });
    }

    Restaurant.isApproved = !Restaurant.isApproved;
    await Restaurant.save();

    res.status(200).json({
      success: true,
      message: `Restaurant ${Restaurant.isApproved ? "approved" : "disapproved"} successfully`,
      data: Restaurant,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
exports.getAllOrders = async (req, res) => {
  try {
    const orders = await Order.find()
      .populate("user", "name email")
      .populate("restaurant", "name");
    res.status(200).json({
      success: true,
      data: orders,
      count: orders.length,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

exports.getPlatformStatistics = async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalRestaurants = await restaurant.countDocuments();
    const totalOrders = await Order.countDocuments();

    const totalRevenue = await Order.aggregate([
      { $match: { paymentStatus: "Paid" } },
      {
        $group: {
          _id: null,
          totalRevenue: { $sum: "$totalAmount" },
        },
      },
    ]);

    res.status(200).json({
      success: true,
      data: {
        totalUsers,
        totalRestaurants,
        totalOrders,
        totalRevenue:
          totalRevenue.length > 0 ? totalRevenue[0].totalRevenue : 0,
      },
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// ================= FRAUD MANAGEMENT =================

// Get all fraud reports
exports.getFraudOrders = async (req, res) => {
  try {
    const reports = await FraudReport.find()
      .populate("user", "name email")
      .populate("order")
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: reports.length,
      data: reports,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Review a fraud report
exports.reviewFraudOrder = async (req, res) => {
  try {
    const { status, adminRemark } = req.body;

    const report = await FraudReport.findById(req.params.id);

    if (!report) {
      return res.status(404).json({
        success: false,
        message: "Fraud report not found",
      });
    }

    report.status = status;
    report.adminRemark = adminRemark;

    await report.save();

    res.status(200).json({
      success: true,
      message: "Fraud report updated successfully",
      data: report,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// Restrict a suspicious user
exports.restrictUser = async (req, res) => {
  try {
    const report = await FraudReport.findById(req.params.id);

    if (!report) {
      return res.status(404).json({
        success: false,
        message: "Fraud report not found",
      });
    }

    const user = await User.findById(report.user);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: "User not found",
      });
    }

    const { days = 7 } = req.body;

    // Restrict user
    user.isblocked = true;

    // Calculate restriction expiry
    const blockedUntil = new Date();
    blockedUntil.setDate(blockedUntil.getDate() + Number(days));

    user.blockedUntil = blockedUntil;

    await user.save();

    res.status(200).json({
      success: true,
      message: `User restricted for ${days} day(s)`,
      blockedUntil,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

exports.createRestaurantByAdmin = async (req, res) => {
  try {
    const createdRestaurant = await Restaurant.create({
      ...req.body,
      isApproved: true,
    });

    res.status(201).json({
      success: true,
      message: "Restaurant created successfully",
      data: createdRestaurant,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

exports.updateRestaurantByAdmin = async (req, res) => {
  try {
    const updatedRestaurant = await Restaurant.findByIdAndUpdate(
      req.params.restaurantId,
      req.body,
      {
        new: true,
      }
    );

    if (!updatedRestaurant) {
      return res.status(404).json({
        success: false,
        message: "Restaurant not found",
      });
    }

    res.status(200).json({
      success: true,
      message: "Restaurant updated successfully",
      data: updatedRestaurant,
    });

  } catch (error) {

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }
};

exports.getSurgeSettings = async (req, res) => {
  try {

    let settings = await SurgeSetting.findOne();

    if (!settings) {
      settings = await SurgeSetting.create({});
    }

    res.status(200).json({
      success: true,
      data: settings,
    });

  } catch (error) {

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }
};

exports.updateSurgeSettings = async (req, res) => {
  try {

    let settings = await SurgeSetting.findOne();

    if (!settings) {
      settings = await SurgeSetting.create({});
    }

    Object.assign(settings, req.body);

    await settings.save();

    res.status(200).json({
      success: true,
      message: "Surge settings updated successfully",
      data: settings,
    });

  } catch (error) {

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }
};

// ==============================
// Get All Refund Requests
// ==============================
exports.getAllRefundRequests = async (req, res) => {
  try {

    const refunds = await Refund.find()
      .populate("user", "name email")
      .populate("order")
      .sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: refunds.length,
      data: refunds,
    });

  } catch (error) {

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }
};

// ==============================
// Review Refund Request
// ==============================
exports.reviewRefundRequest = async (req, res) => {
  try {

    const { status, adminRemark } = req.body;

    if (!["Approved", "Rejected"].includes(status)) {
      return res.status(400).json({
        success: false,
        message: "Status must be Approved or Rejected",
      });
    }

    const refund = await Refund.findById(req.params.id);

    if (!refund) {
      return res.status(404).json({
        success: false,
        message: "Refund request not found",
      });
    }

    refund.status = status;
    refund.adminRemark = adminRemark || "";

    await refund.save();

    res.status(200).json({
      success: true,
      message: "Refund request updated successfully",
      data: refund,
    });

  } catch (error) {

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }
};