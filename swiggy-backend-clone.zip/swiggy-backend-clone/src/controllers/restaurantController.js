const Fuse = require("fuse.js");

const Restaurant = require("../models/restaurant");

const {
  getRecommendedRestaurants,
} = require("../services/recommendationService");

exports.createRestaurant = async (req, res) => {
  try {
    if (req.user.role !== "restaurant") {
      return res.status(403).json({
        success: false,
        message: "Only restaurant owners can create restaurants",
      });
    }
    const existingRestaurant = await Restaurant.findOne({
      owner: req.user._id,
    });
    if (existingRestaurant) {
      return res.status(400).json({
        success: false,
        message: "You already have a restaurant registered",
      });
    }
    const createdRestaurant = await Restaurant.create({
      ...req.body,
      owner: req.user._id,
    });
    res.status(201).json({
      success: true,
      message: "Restaurant created successfully",
      data: createdRestaurant,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error creating restaurant",
      error: error.message,
    });
  }
};

exports.getMyRestaurant = async (req, res) => {
  try {
    const restaurant = await Restaurant.findOne({ owner: req.user._id });
    if (!restaurant) {
      return res.status(404).json({
        success: false,
        message: "You don't have a restaurant registered",
      });
    }
    res.status(200).json({
      success: true,
      data: restaurant,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching restaurant",
      error: error.message,
    });
  }
};

exports.updateRestaurant = async (req, res) => {
  try {
    const restaurant = await Restaurant.findOne({ owner: req.user._id });
    if (!restaurant) {
      return res.status(404).json({
        success: false,
        message: "You don't have a restaurant registered",
      });
    }
    if (restaurant.owner.toString() !== req.user._id.toString()) {
      return res.status(403).json({
        success: false,
        message: "You are not authorized to update this restaurant",
      });
    }
    const updatedRestaurant = await Restaurant.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true },
    );
    res.status(200).json({
      success: true,
      message: "Restaurant updated successfully",
      data: updatedRestaurant,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error updating restaurant",
      error: error.message,
    });
  }
};
exports.getAllRestaurants = async (req, res) => {
  try {
    const { city, page = 1, limit = 10 } = req.query;
    const query = { isApproved: true };
    if (city) {
      query.city = city;
    }
    const restaurants = await Restaurant
      .find(query)
      .skip((page - 1) * limit)
      .limit(limit)
      .sort({ createdAt: -1 });
    res.status(200).json({
      success: true,
      data: restaurants,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: "Error fetching restaurants",
      error: error.message,
    });
  }
};

// Advanced Restaurant Search
exports.searchRestaurants = async (req, res) => {
  try {
    const {
      keyword,
      cuisine,
      rating,
      maxPrice,
      maxDeliveryTime,
      veg,
      sort,
    } = req.query;

    const pipeline = [];

    // Text search must be the first pipeline stage
    if (keyword) {
      pipeline.push({
        $match: {
          $text: {
            $search: keyword,
          },
        },
      });
    }

    // Filter approved restaurants
    pipeline.push({
      $match: {
        isApproved: true,
      },
    });

    // Cuisine filter
    if (cuisine) {
      pipeline.push({
        $match: {
          cuisine: cuisine,
        },
      });
    }

    // Rating filter
    if (rating) {
      pipeline.push({
        $match: {
          rating: {
            $gte: Number(rating),
          },
        },
      });
    }

    // Price filter
    if (maxPrice) {
      pipeline.push({
        $match: {
          priceRange: {
            $lte: Number(maxPrice),
          },
        },
      });
    }

    // Delivery Time filter
    if (maxDeliveryTime) {
      pipeline.push({
        $match: {
          estimatedDeliveryTime: {
            $lte: Number(maxDeliveryTime),
          },
        },
      });
    }

    // Veg filter
    if (veg === "true") {
      pipeline.push({
        $match: {
          isPureVeg: true,
        },
      });
    }

    // Sorting
    switch (sort) {
      case "rating":
        pipeline.push({
          $sort: {
            rating: -1,
          },
        });
        break;

      case "delivery":
        pipeline.push({
          $sort: {
            estimatedDeliveryTime: 1,
          },
        });
        break;

      case "price":
        pipeline.push({
          $sort: {
            priceRange: 1,
          },
        });
        break;

      default:
        pipeline.push({
          $sort: {
            popularity: -1,
          },
        });
    }

    let restaurants = await Restaurant.aggregate(pipeline);

    // Apply fuzzy search if keyword exists
    if (keyword) {
      const fuse = new Fuse(restaurants, {
        keys: ["name", "city", "cuisine"],
        threshold: 0.4,
        ignoreLocation: true,
      });

      restaurants = fuse.search(keyword).map(result => result.item);
    }

    res.status(200).json({
      success: true,
      count: restaurants.length,
      data: restaurants,
    });

  } catch (error) {

    res.status(500).json({
      success: false,
      message: error.message,
    });

  }
};

exports.getRecommendations = async (req, res) => {
  try {
    const { userId } = req.params;

    const recommendations = await getRecommendedRestaurants(userId);

    res.status(200).json({
      success: true,
      count: recommendations.length,
      recommendations,
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};
