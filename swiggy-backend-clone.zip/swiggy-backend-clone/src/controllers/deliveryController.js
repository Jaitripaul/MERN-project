const DeliveryPartner = require("../models/DeliveryPartner");
const Order = require("../models/order");
const Restaurant = require("../models/restaurant");

const {
  assignDeliveryPartner,
} = require("../services/deliveryAssignmentService");

// =======================
// Create Delivery Partner
// =======================
exports.createDeliveryPartner = async (req, res) => {
  try {
    const {
      name,
      phone,
      email,
      latitude,
      longitude,
    } = req.body;

    const existingPartner = await DeliveryPartner.findOne({
      $or: [{ email }, { phone }],
    });

    if (existingPartner) {
      return res.status(400).json({
        success: false,
        message: "Delivery partner already exists",
      });
    }

    const partner = await DeliveryPartner.create({
      name,
      phone,
      email,
      location: {
        latitude,
        longitude,
      },
    });

    res.status(201).json({
      success: true,
      message: "Delivery partner created successfully",
      data: partner,
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// =======================
// Update Availability
// =======================
exports.setAvailabilityStatus = async (req, res) => {
  try {
    const { partnerId, isAvailable } = req.body;

    const partner = await DeliveryPartner.findById(partnerId);

    if (!partner) {
      return res.status(404).json({
        success: false,
        message: "Delivery partner not found",
      });
    }

    partner.isAvailable = isAvailable;

    await partner.save();

    res.status(200).json({
      success: true,
      message: "Availability updated successfully",
      data: partner,
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

// =======================
// Decline Delivery
// =======================
exports.declineDelivery = async (req, res) => {
  try {
    const { orderId } = req.params;

    const order = await Order.findById(orderId);

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    if (!order.deliveryPartner) {
      return res.status(400).json({
        success: false,
        message: "No delivery partner assigned",
      });
    }

    // Reduce current partner workload
    const oldPartner = await DeliveryPartner.findById(
      order.deliveryPartner
    );

    if (oldPartner && oldPartner.currentOrders > 0) {
      oldPartner.currentOrders -= 1;
      await oldPartner.save();
    }

    // Load restaurant to get location
    const restaurant = await Restaurant.findById(order.restaurant);

    if (!restaurant || !restaurant.location) {
      return res.status(400).json({
        success: false,
        message: "Restaurant location not found",
      });
    }

    // Assign another delivery partner
    const newPartner = await assignDeliveryPartner(
      restaurant.location
    );

    if (!newPartner) {
      order.deliveryPartner = null;
      await order.save();

      return res.status(200).json({
        success: true,
        message: "No other delivery partner available",
        data: order,
      });
    }

    order.deliveryPartner = newPartner._id;
    await order.save();

    res.status(200).json({
      success: true,
      message: "Delivery partner reassigned successfully",
      data: order,
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};

exports.declineDelivery = async (req, res) => {
  try {
    const { orderId } = req.params;

    const order = await Order.findById(orderId);

    if (!order) {
      return res.status(404).json({
        success: false,
        message: "Order not found",
      });
    }

    if (!order.deliveryPartner) {
      return res.status(400).json({
        success: false,
        message: "No delivery partner assigned",
      });
    }

    // Free the current partner
    const currentPartner = await DeliveryPartner.findById(
      order.deliveryPartner
    );

    if (currentPartner && currentPartner.currentOrders > 0) {
      currentPartner.currentOrders -= 1;
      await currentPartner.save();
    }

    // Get restaurant location
    const Restaurant = await restaurant.findById(order.restaurant);

    if (!Restaurant) {
      return res.status(404).json({
        success: false,
        message: "Restaurant not found",
      });
    }

    // Assign another partner
    const newPartner = await assignDeliveryPartner(
      Restaurant.location
    );

    if (!newPartner) {
      order.deliveryPartner = null;
      await order.save();

      return res.status(200).json({
        success: true,
        message: "No delivery partner available for reassignment",
        data: order,
      });
    }

    order.deliveryPartner = newPartner._id;
    await order.save();

    res.status(200).json({
      success: true,
      message: "Delivery partner reassigned successfully",
      data: order,
    });

  } catch (error) {
    res.status(500).json({
      success: false,
      message: error.message,
    });
  }
};